x=input("Ingrese un numero ")
x=float(x)
if x>0:
    print("El número es positivo")
   
if x<0:
    print("El número es negativo")

if x==0:
    print("El número es 0")