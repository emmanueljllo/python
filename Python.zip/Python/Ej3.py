x=input("Ingrese un número ")
x=int(x)

if x%2==0:
    print("Es par")
else:
    print("Es impar")