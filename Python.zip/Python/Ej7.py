x=input("Ingrese el primer número ")
y=input("Ingrese el segundo número ")




if x>y:
    print("El numero mayor es "+x)
elif x<y:
    print("El número mayor es "+y)


