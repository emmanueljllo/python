y="python123"
x=input("Ingrese su contraseña ")

if x==y:
    print("Acceso concedido")
else:
    print("Contrasela incorrecta")
