nombre= input("Por favor dame tu nombre ")
apellido= input("Por favor dame tu apellido ")
edad= input("Por favor dame tu edad ")
print("Su nombre es "+nombre+" , su apellido es "+apellido+" y tienes "+edad+" años")
