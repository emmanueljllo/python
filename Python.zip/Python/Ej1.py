x = input("Ingrese su edad ")  
x=int(x)

if x>=18:
    print("Eres mayor de edad")
else:
    print("Eres menor de edad")



